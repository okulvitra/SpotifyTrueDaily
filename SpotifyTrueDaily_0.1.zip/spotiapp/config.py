# config_template.py
# Copiez ce fichier en config.py et remplissez vos informations personnelles.
# NE PARTAGEZ PAS VOTRE FICHIER config.py !

# Configuration Spotify
SPOTIPY_CLIENT_ID = 'e43917d13c6e459fb9f473fe41c0e13e'
SPOTIPY_CLIENT_SECRET = '357e9abc4214466fbf5df362d3c90ea5'
SPOTIPY_REDIRECT_URI = 'http://127.0.0.1:8888/callback' # Ou votre URI de redirection

# Configuration SoundStat
SOUNDSTAT_API_KEY = '1Z4XXVmCo13Qy4hjTz_uWluLm-MUe1rrpIGNZ7nNpaE'

# Options de la Playlist (vous pouvez aussi les laisser dans le script principal si elles ne sont pas secrètes)
# PLAYLIST_NAME = "Journalière"
# MAX_RECENT_TRACKS = 5
# etc.